import Box from '@mui/material/Box'
import Container from '@mui/material/Container'
import Grid from '@mui/material/Grid'
import Typography from '@mui/material/Typography'
import { useParams } from 'react-router-dom'
import Navbar from "../components/Navbar"
import structures from "../data"

function Building() {
  const { id } = useParams();
  const building = structures[Number(id)];

  return (
    <div>
      <Navbar active="1"/>
      <Container maxWidth="lg" sx={{ mt: '20px' }}>
        <Typography
          variant="h4"
          component="h1"
          sx={{ textAlign: 'center', mb: '20px', color: 'text.secondary' }}
        >
          {building.title}
        </Typography>
        <Box
          component="img"
          src={building.img}
          alt={building.title}
          sx={{
            display: 'block',
            width: { xs: '100%', sm: '70%', md: '40%' },
            maxWidth: '420px',
            mx: 'auto',
            mb: '25px',
          }}
        />
        <Grid container spacing={{ xs: 2, md: 4 }}>
          {building.description.map((item, index) => (
            <Grid key={index} size={{ xs: 12, md: 6 }}>
              <Typography variant="body2" sx={{ textAlign: 'justify' }}>
                {item}
              </Typography>
            </Grid>
          ))}
        </Grid>
      </Container>
    </div>
  );
}

export default Building;
