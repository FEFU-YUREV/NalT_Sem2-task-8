import Box from '@mui/material/Box'
import Typography from '@mui/material/Typography'

function Footer() {
  return (
    <Box sx={{ mt: 4, py: 3, textAlign: 'center', bgcolor: 'grey.100' }}>
      <Typography variant="body1">
        Выполнил: Юрьев Артём
      </Typography>
      <Typography variant="body2" color="text.secondary">
        Б9123-09.03.04(5)
      </Typography>
    </Box>
  )
}

export default Footer
